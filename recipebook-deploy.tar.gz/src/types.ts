export interface Recipe {
  id: string;
  title: string;
  description: string;
  prep_time: string;
  cook_time: string;
  servings: number;
  ingredients: Ingredient[];
  instructions: Instruction[];
  category: string;
  image_url: string;
  favorite: boolean;
  source: string;
  source_url: string;
  tags?: string[];
  rating?: number;
  notes?: string;
  nutrition?: NutritionInfo;
  created_at: string;
  updated_at: string;
}

export interface NutritionInfo {
  calories?: number;
  protein?: number;
  carbs?: number;
  fat?: number;
  fiber?: number;
}

export interface Ingredient {
  item: string;
  amount: string;
}

export interface Instruction {
  step: number;
  text: string;
}

export interface MealPlan {
  id: string;
  day: string;
  date: string;
  meal_type: string;
  recipe_id: string;
  servings: number;
  created_at: string;
  recipe?: Recipe;
}

export interface ShoppingListItem {
  id: string;
  ingredient_name: string;
  quantity: string;
  unit: string;
  checked: boolean;
  created_at: string;
}
