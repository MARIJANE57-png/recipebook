import { Clock, Users, Heart, Trash2, Edit, ChefHat } from 'lucide-react';
import { Recipe } from '../types';
import { useState } from 'react';

interface RecipeCardProps {
  recipe: Recipe;
  onEdit: (recipe: Recipe) => void;
  onDelete: (id: string) => void;
  onToggleFavorite: (id: string, favorite: boolean) => void;
}

export default function RecipeCard({ recipe, onEdit, onDelete, onToggleFavorite }: RecipeCardProps) {
  const [imageError, setImageError] = useState(false);
  const showPlaceholder = !recipe.image_url || imageError;

  return (
    <div className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow overflow-hidden">
      <div className="h-48 bg-gradient-to-br from-emerald-100 to-teal-100 relative">
        {showPlaceholder ? (
          <div className="w-full h-full flex items-center justify-center">
            <ChefHat className="w-16 h-16 text-emerald-300" />
          </div>
        ) : (
          <img
            src={recipe.image_url}
            alt={recipe.title}
            className="w-full h-full object-cover"
            onError={() => setImageError(true)}
          />
        )}
        <button
          onClick={() => onToggleFavorite(recipe.id, !recipe.favorite)}
          className="absolute top-3 right-3 p-2 bg-white rounded-full shadow-md hover:scale-110 transition-transform"
        >
          <Heart
            className={`w-5 h-5 ${recipe.favorite ? 'fill-red-500 text-red-500' : 'text-gray-400'}`}
          />
        </button>
      </div>
      <div className="p-4">
        <div className="flex items-start justify-between mb-2">
          <h3 className="font-semibold text-lg text-gray-900 flex-1">{recipe.title}</h3>
          <span className="px-2 py-1 text-xs font-medium bg-emerald-100 text-emerald-700 rounded-full">
            {recipe.category}
          </span>
        </div>
        <p className="text-gray-600 text-sm mb-4 line-clamp-2">{recipe.description}</p>
        <div className="flex items-center gap-4 text-sm text-gray-500 mb-4">
          <div className="flex items-center gap-1">
            <Clock className="w-4 h-4" />
            <span>{recipe.prep_time || '0'} + {recipe.cook_time || '0'} min</span>
          </div>
          <div className="flex items-center gap-1">
            <Users className="w-4 h-4" />
            <span>{recipe.servings} servings</span>
          </div>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => onEdit(recipe)}
            className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors"
          >
            <Edit className="w-4 h-4" />
            Edit
          </button>
          <button
            onClick={() => onDelete(recipe.id)}
            className="px-4 py-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition-colors"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
