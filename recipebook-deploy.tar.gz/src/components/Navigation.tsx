import { BookOpen, Calendar, ShoppingCart, Download, Sun, Moon } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

interface NavigationProps {
  currentView: 'recipes' | 'meal-plan' | 'shopping';
  onViewChange: (view: 'recipes' | 'meal-plan' | 'shopping') => void;
}

export default function Navigation({ currentView, onViewChange }: NavigationProps) {
  const { theme, toggleTheme } = useTheme();

  return (
    <>
      <header style={{
        background: 'var(--bg-secondary)',
        padding: '20px',
        borderBottom: '1px solid var(--border-color)',
        position: 'sticky',
        top: 0,
        zIndex: 50,
        backdropFilter: 'blur(20px)',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center'
      }}>
        <div style={{ width: '40px' }} />
        <h1 style={{
          fontFamily: "'Playfair Display', Georgia, serif",
          fontSize: '32px',
          fontWeight: 700,
          color: 'var(--text-primary)',
          letterSpacing: '-0.5px',
          margin: 0
        }}>
          Recipe Society
        </h1>
        <button
          onClick={toggleTheme}
          style={{
            background: 'var(--bg-tertiary)',
            border: '1px solid var(--border-color)',
            borderRadius: '8px',
            padding: '8px',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            transition: 'all 0.3s ease',
            color: 'var(--text-primary)'
          }}
          aria-label="Toggle theme"
        >
          {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
        </button>
      </header>

      <nav style={{
        position: 'fixed',
        bottom: 0,
        left: 0,
        right: 0,
        background: 'var(--bg-secondary)',
        borderTop: '1px solid var(--border-color)',
        display: 'flex',
        justifyContent: 'space-around',
        padding: '8px 0',
        zIndex: 100,
        backdropFilter: 'blur(20px)',
        height: '70px'
      }}>
        <a
          href="#"
          onClick={(e) => e.preventDefault()}
          style={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '4px',
            flex: 1,
            padding: '8px',
            color: 'var(--text-secondary)',
            textDecoration: 'none',
            position: 'relative',
            opacity: 0.4,
            cursor: 'not-allowed'
          }}
        >
          <Download style={{ width: 24, height: 24 }} />
          <span style={{ fontSize: '11px', fontWeight: 500, letterSpacing: '0.3px' }}>Import</span>
        </a>

        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            onViewChange('recipes');
          }}
          style={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '4px',
            flex: 1,
            padding: '8px',
            color: currentView === 'recipes' ? 'var(--accent-color)' : 'var(--text-secondary)',
            textDecoration: 'none',
            position: 'relative'
          }}
        >
          {currentView === 'recipes' && (
            <div style={{
              position: 'absolute',
              top: 0,
              left: '50%',
              transform: 'translateX(-50%)',
              width: '40px',
              height: '3px',
              background: 'var(--accent-color)',
              borderRadius: '0 0 3px 3px'
            }} />
          )}
          <BookOpen style={{ width: 24, height: 24 }} />
          <span style={{ fontSize: '11px', fontWeight: 500, letterSpacing: '0.3px' }}>Recipe Book</span>
        </a>

        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            onViewChange('meal-plan');
          }}
          style={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '4px',
            flex: 1,
            padding: '8px',
            color: currentView === 'meal-plan' ? 'var(--accent-color)' : 'var(--text-secondary)',
            textDecoration: 'none',
            position: 'relative'
          }}
        >
          {currentView === 'meal-plan' && (
            <div style={{
              position: 'absolute',
              top: 0,
              left: '50%',
              transform: 'translateX(-50%)',
              width: '40px',
              height: '3px',
              background: 'var(--accent-color)',
              borderRadius: '0 0 3px 3px'
            }} />
          )}
          <Calendar style={{ width: 24, height: 24 }} />
          <span style={{ fontSize: '11px', fontWeight: 500, letterSpacing: '0.3px' }}>Meal Plan</span>
        </a>

        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            onViewChange('shopping');
          }}
          style={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '4px',
            flex: 1,
            padding: '8px',
            color: currentView === 'shopping' ? 'var(--accent-color)' : 'var(--text-secondary)',
            textDecoration: 'none',
            position: 'relative'
          }}
        >
          {currentView === 'shopping' && (
            <div style={{
              position: 'absolute',
              top: 0,
              left: '50%',
              transform: 'translateX(-50%)',
              width: '40px',
              height: '3px',
              background: 'var(--accent-color)',
              borderRadius: '0 0 3px 3px'
            }} />
          )}
          <ShoppingCart style={{ width: 24, height: 24 }} />
          <span style={{ fontSize: '11px', fontWeight: 500, letterSpacing: '0.3px' }}>Shopping List</span>
        </a>
      </nav>
    </>
  );
}
