import { useState, useEffect } from 'react';
import { Plus, Trash2, RefreshCw, Printer, Share2 } from 'lucide-react';
import { ShoppingListItem, MealPlan } from '../types';
import { supabase } from '../lib/supabase';

export default function ShoppingListView() {
  const [items, setItems] = useState<ShoppingListItem[]>([]);
  const [newItemName, setNewItemName] = useState('');
  const [newItemQuantity, setNewItemQuantity] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadItems();
  }, []);

  const loadItems = async () => {
    try {
      const { data, error } = await supabase
        .from('shopping_list_items')
        .select('*')
        .order('checked', { ascending: true })
        .order('created_at', { ascending: false });

      if (error) throw error;
      setItems(data || []);
    } catch (error) {
      console.error('Error loading shopping list:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemName.trim()) return;

    try {
      const { error } = await supabase
        .from('shopping_list_items')
        .insert([{
          ingredient_name: newItemName.trim(),
          quantity: newItemQuantity.trim(),
          unit: '',
          checked: false,
        }]);

      if (error) throw error;
      setNewItemName('');
      setNewItemQuantity('');
      await loadItems();
    } catch (error) {
      console.error('Error adding item:', error);
    }
  };

  const handleToggleCheck = async (id: string, checked: boolean) => {
    try {
      const { error } = await supabase
        .from('shopping_list_items')
        .update({ checked })
        .eq('id', id);

      if (error) throw error;
      await loadItems();
    } catch (error) {
      console.error('Error updating item:', error);
    }
  };

  const handleDeleteItem = async (id: string) => {
    try {
      const { error } = await supabase
        .from('shopping_list_items')
        .delete()
        .eq('id', id);

      if (error) throw error;
      await loadItems();
    } catch (error) {
      console.error('Error deleting item:', error);
    }
  };

  const handleClearChecked = async () => {
    if (!confirm('Clear all checked items?')) return;

    try {
      const { error } = await supabase
        .from('shopping_list_items')
        .delete()
        .eq('checked', true);

      if (error) throw error;
      await loadItems();
    } catch (error) {
      console.error('Error clearing checked items:', error);
    }
  };

  const handleGenerateFromMealPlan = async () => {
    try {
      const today = new Date();
      const weekFromNow = new Date(today);
      weekFromNow.setDate(weekFromNow.getDate() + 7);

      const { data: mealPlans, error: mealError } = await supabase
        .from('meal_plans')
        .select('*, recipe:recipes(*)')
        .gte('date', today.toISOString().split('T')[0])
        .lte('date', weekFromNow.toISOString().split('T')[0]);

      if (mealError) throw mealError;

      const ingredientMap = new Map<string, { quantity: string; count: number }>();

      (mealPlans as MealPlan[]).forEach((plan) => {
        if (plan.recipe?.ingredients) {
          plan.recipe.ingredients.forEach((ingredient: any) => {
            const name = ingredient.item.toLowerCase();
            if (ingredientMap.has(name)) {
              const existing = ingredientMap.get(name)!;
              ingredientMap.set(name, {
                quantity: existing.quantity,
                count: existing.count + 1,
              });
            } else {
              ingredientMap.set(name, {
                quantity: ingredient.amount || '',
                count: 1,
              });
            }
          });
        }
      });

      const newItems = Array.from(ingredientMap.entries()).map(([name, data]) => ({
        ingredient_name: name,
        quantity: data.count > 1 ? `${data.quantity} (×${data.count})` : data.quantity,
        unit: '',
        checked: false,
      }));

      if (newItems.length > 0) {
        const { error: insertError } = await supabase
          .from('shopping_list_items')
          .insert(newItems);

        if (insertError) throw insertError;
        await loadItems();
      }
    } catch (error) {
      console.error('Error generating shopping list:', error);
    }
  };

  const handlePrint = () => {
    const uncheckedItems = items.filter((item) => !item.checked);
    const checkedItems = items.filter((item) => item.checked);

    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const printContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Shopping List</title>
          <style>
            @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Montserrat:wght@300;400;500;600&display=swap');

            body {
              font-family: 'Montserrat', sans-serif;
              max-width: 800px;
              margin: 20px auto;
              padding: 20px;
            }
            h1 {
              font-family: 'Playfair Display', serif;
              color: #2d3a2e;
              border-bottom: 2px solid #8b9d83;
              padding-bottom: 10px;
            }
            .section {
              margin-top: 20px;
            }
            .section h2 {
              font-size: 18px;
              color: #374151;
              margin-bottom: 10px;
            }
            .item {
              display: flex;
              padding: 8px 0;
              border-bottom: 1px solid #e5e7eb;
            }
            .checkbox {
              width: 18px;
              height: 18px;
              border: 2px solid #8b9d83;
              margin-right: 12px;
              flex-shrink: 0;
              border-radius: 3px;
            }
            .name {
              font-weight: 500;
              flex: 1;
            }
            .quantity {
              color: #6b7280;
              margin-left: 10px;
            }
            .print-button {
              position: fixed;
              top: 20px;
              right: 20px;
              background: #8b9d83;
              color: white;
              border: none;
              padding: 12px 24px;
              border-radius: 8px;
              font-family: 'Montserrat', sans-serif;
              font-weight: 500;
              cursor: pointer;
              box-shadow: 0 2px 8px rgba(0,0,0,0.1);
              font-size: 14px;
              z-index: 1000;
            }
            .print-button:hover {
              background: #7a8c74;
            }
            @media print {
              body {
                margin: 0;
                padding: 20px;
              }
              .print-button {
                display: none;
              }
            }
          </style>
        </head>
        <body>
          <button class="print-button" onclick="window.print()">Print</button>
          <h1>Shopping List</h1>
          ${uncheckedItems.length > 0 ? `
            <div class="section">
              <h2>To Buy (${uncheckedItems.length} items)</h2>
              ${uncheckedItems.map(item => `
                <div class="item">
                  <div class="checkbox"></div>
                  <span class="name">${item.ingredient_name}</span>
                  ${item.quantity ? `<span class="quantity">${item.quantity}</span>` : ''}
                </div>
              `).join('')}
            </div>
          ` : ''}
          ${checkedItems.length > 0 ? `
            <div class="section">
              <h2>Checked Off (${checkedItems.length} items)</h2>
              ${checkedItems.map(item => `
                <div class="item" style="opacity: 0.6; text-decoration: line-through;">
                  <div class="checkbox" style="background: #8b9d83;"></div>
                  <span class="name">${item.ingredient_name}</span>
                  ${item.quantity ? `<span class="quantity">${item.quantity}</span>` : ''}
                </div>
              `).join('')}
            </div>
          ` : ''}
        </body>
      </html>
    `;

    printWindow.document.write(printContent);
    printWindow.document.close();
  };

  const handleExportToReminders = () => {
    const text = uncheckedItems
      .map(item => `${item.ingredient_name}${item.quantity ? ` - ${item.quantity}` : ''}`)
      .join('\n');

    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'shopping-list.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    alert('Shopping list downloaded! On your iPhone:\n\n1. Open the file\n2. Select all text and copy\n3. Open Reminders app\n4. Paste the list\n5. Each line will become a separate reminder');
  };

  const uncheckedItems = items.filter((item) => !item.checked);
  const checkedItems = items.filter((item) => item.checked);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-500">Loading shopping list...</div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-3xl font-bold text-gray-900">Shopping List</h2>
            <p className="text-gray-600 mt-1">
              {uncheckedItems.length} items to buy, {checkedItems.length} checked off
            </p>
          </div>
          <div className="flex gap-3">
            <button
              onClick={handlePrint}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                padding: '8px 16px',
                background: 'color-mix(in srgb, #8b9d83 15%, transparent)',
                color: '#6b7c63',
                border: '1px solid #8b9d83',
                borderRadius: '8px',
                fontSize: '14px',
                fontWeight: 500,
                cursor: 'pointer',
                transition: 'all 0.2s'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = '#8b9d83';
                e.currentTarget.style.color = 'white';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = 'color-mix(in srgb, #8b9d83 15%, transparent)';
                e.currentTarget.style.color = '#6b7c63';
              }}
              title="Print shopping list"
            >
              <Printer className="w-4 h-4" />
              Print
            </button>
            <button
              onClick={handleExportToReminders}
              className="flex items-center gap-2 px-4 py-2 bg-slate-50 text-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
              title="Export to iPhone Reminders"
            >
              <Share2 className="w-4 h-4" />
              Export
            </button>
            <button
              onClick={handleGenerateFromMealPlan}
              className="flex items-center gap-2 px-4 py-2 bg-emerald-50 text-emerald-700 rounded-lg hover:bg-emerald-100 transition-colors"
            >
              <RefreshCw className="w-4 h-4" />
              Generate from Meal Plan
            </button>
            {checkedItems.length > 0 && (
              <button
                onClick={handleClearChecked}
                className="flex items-center gap-2 px-4 py-2 bg-red-50 text-red-700 rounded-lg hover:bg-red-100 transition-colors"
              >
                <Trash2 className="w-4 h-4" />
                Clear Checked
              </button>
            )}
          </div>
        </div>

        <form onSubmit={handleAddItem} className="bg-white rounded-lg shadow-sm p-4 mb-6">
          <div className="flex gap-3">
            <input
              type="text"
              placeholder="Item name..."
              value={newItemName}
              onChange={(e) => setNewItemName(e.target.value)}
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
            />
            <input
              type="text"
              placeholder="Quantity..."
              value={newItemQuantity}
              onChange={(e) => setNewItemQuantity(e.target.value)}
              className="w-32 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
            />
            <button
              type="submit"
              className="flex items-center gap-2 px-6 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors"
            >
              <Plus className="w-5 h-5" />
              Add
            </button>
          </div>
        </form>
      </div>

      <div className="space-y-6">
        {uncheckedItems.length > 0 && (
          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            <div className="p-4 bg-gray-50 border-b">
              <h3 className="font-semibold text-gray-900">To Buy</h3>
            </div>
            <div className="divide-y">
              {uncheckedItems.map((item) => (
                <div key={item.id} className="p-4 flex items-center gap-4 hover:bg-gray-50 transition-colors">
                  <input
                    type="checkbox"
                    checked={item.checked}
                    onChange={(e) => handleToggleCheck(item.id, e.target.checked)}
                    className="w-5 h-5 text-emerald-600 rounded focus:ring-2 focus:ring-emerald-500"
                  />
                  <div className="flex-1">
                    <div className="font-medium text-gray-900">{item.ingredient_name}</div>
                    {item.quantity && (
                      <div className="text-sm text-gray-500">{item.quantity}</div>
                    )}
                  </div>
                  <button
                    onClick={() => handleDeleteItem(item.id)}
                    className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {checkedItems.length > 0 && (
          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            <div className="p-4 bg-gray-50 border-b">
              <h3 className="font-semibold text-gray-900">Checked Off</h3>
            </div>
            <div className="divide-y">
              {checkedItems.map((item) => (
                <div key={item.id} className="p-4 flex items-center gap-4 hover:bg-gray-50 transition-colors opacity-60">
                  <input
                    type="checkbox"
                    checked={item.checked}
                    onChange={(e) => handleToggleCheck(item.id, e.target.checked)}
                    className="w-5 h-5 text-emerald-600 rounded focus:ring-2 focus:ring-emerald-500"
                  />
                  <div className="flex-1">
                    <div className="font-medium text-gray-900 line-through">{item.ingredient_name}</div>
                    {item.quantity && (
                      <div className="text-sm text-gray-500 line-through">{item.quantity}</div>
                    )}
                  </div>
                  <button
                    onClick={() => handleDeleteItem(item.id)}
                    className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {items.length === 0 && (
          <div className="text-center py-12 bg-white rounded-lg shadow-sm">
            <p className="text-gray-500 text-lg">
              Your shopping list is empty. Add items manually or generate from your meal plan!
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
