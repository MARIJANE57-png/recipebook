import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface RecommendRequest {
  prompt: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { prompt }: RecommendRequest = await req.json();

    if (!prompt || prompt.trim().length === 0) {
      return new Response(
        JSON.stringify({ error: 'Prompt is required' }),
        {
          status: 400,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json',
          },
        }
      );
    }

    // Get API key from environment
    const apiKey = Deno.env.get('OPENAI_API_KEY');
    
    if (!apiKey) {
      console.error('OPENAI_API_KEY is not set');
      return new Response(
        JSON.stringify({ error: 'AI service is not configured. Please set OPENAI_API_KEY in Supabase Vault.' }),
        {
          status: 500,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json',
          },
        }
      );
    }

    const systemPrompt = `You are Recipe Society AI, a premium culinary assistant for women aged 35+ who want realistic, modern, healthy meals that fit their lifestyle.

IMPORTANT RESTRICTIONS:
- NEVER browse the internet
- NEVER use external websites as sources
- NEVER reference or pull from commercial food blogs, low-quality recipe sites, or content farms
- ALL recipes MUST be original creations

STYLE GUIDELINES:
Use ONLY these style inspirations for tone and vibe (NOT as recipe sources):
- NYT Cooking (clean, minimal, modern)
- Half-Baked Harvest (fresh, balanced, colorful, modern comfort)
- Mediterranean wellness cooking (anti-inflammatory, simple ingredients)

PRIORITIES FOR WOMEN 35+:
- Clean healthy meals (balanced, not extreme)
- High-protein meals that feel natural and normal, not "bodybuilder"
- Anti-inflammatory, hormone-friendly options
- Family-friendly healthy meals
- Quick weeknight dinners (20–25 minutes)
- One-pot / one-pan meals for busy schedules
- Simple ingredients available in regular grocery stores

RECIPE REQUIREMENTS:
- Create original, clean, modern Recipe Society–style recipes
- Keep it realistic and match everyday home cooking
- Avoid heavy, overly creamy, ultra-processed, or sugary recipes unless explicitly requested
- Keep descriptions short, clear, and practical

Format your response as a valid JSON object with this exact structure:
{
  "title": "Recipe Name",
  "description": "Brief description (2-3 sentences)",
  "ingredients": [
    {"amount": "1 cup", "item": "ingredient"},
    {"amount": "2", "item": "ingredient"}
  ],
  "instructions": [
    {"step": 1, "text": "First instruction"},
    {"step": 2, "text": "Second instruction"}
  ],
  "prep_time": "15",
  "cook_time": "30",
  "servings": 4,
  "category": "dinner",
  "source": "Recipe Society AI"
}

Respond ONLY with the JSON object, no additional text.`;

    console.log('Calling OpenAI API...');
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: [
          {
            role: 'system',
            content: systemPrompt,
          },
          {
            role: 'user',
            content: prompt,
          },
        ],
        temperature: 0.8,
        max_tokens: 2000,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('OpenAI API error:', response.status, errorText);
      return new Response(
        JSON.stringify({ error: `API error: ${response.status}` }),
        {
          status: 500,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json',
          },
        }
      );
    }

    const data = await response.json();
    const content = data.choices[0].message.content;

    let recipe;
    try {
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        recipe = JSON.parse(jsonMatch[0]);
      } else {
        recipe = JSON.parse(content);
      }
    } catch (parseError) {
      console.error('Failed to parse AI response:', content);
      throw new Error('Failed to parse recipe from AI response');
    }

    return new Response(
      JSON.stringify(recipe),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (error) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({
        error: error instanceof Error ? error.message : 'Failed to get AI recommendation'
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});
