import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface Recipe {
  id: string;
  title: string;
  description?: string;
  prep_time?: string;
  cook_time?: string;
  servings?: number;
  ingredients: string[];
  instructions: string[];
  source?: string;
  source_url?: string;
  favorite: boolean;
  created_at?: string;
  updated_at?: string;
}

export interface MealPlan {
  id: string;
  day: string;
  meal: string;
  recipe_id: string;
  created_at?: string;
}
