import { supabase, MealPlan } from './supabase';

export async function getAllMealPlans(): Promise<MealPlan[]> {
  const { data, error } = await supabase
    .from('meal_plans')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching meal plans:', error);
    return [];
  }

  return data || [];
}

export async function getMealPlanForDay(day: string): Promise<MealPlan[]> {
  const { data, error } = await supabase
    .from('meal_plans')
    .select('*')
    .eq('day', day);

  if (error) {
    console.error('Error fetching meal plans for day:', error);
    return [];
  }

  return data || [];
}

export async function setMealPlan(day: string, meal: string, recipeId: string): Promise<MealPlan | null> {
  const { data: existing } = await supabase
    .from('meal_plans')
    .select('id')
    .eq('day', day)
    .eq('meal', meal)
    .maybeSingle();

  if (existing) {
    const { data, error } = await supabase
      .from('meal_plans')
      .update({ recipe_id: recipeId })
      .eq('id', existing.id)
      .select()
      .single();

    if (error) {
      console.error('Error updating meal plan:', error);
      return null;
    }

    return data;
  } else {
    const { data, error } = await supabase
      .from('meal_plans')
      .insert([{ day, meal, recipe_id: recipeId }])
      .select()
      .single();

    if (error) {
      console.error('Error creating meal plan:', error);
      return null;
    }

    return data;
  }
}

export async function removeMealPlan(day: string, meal: string): Promise<boolean> {
  const { error } = await supabase
    .from('meal_plans')
    .delete()
    .eq('day', day)
    .eq('meal', meal);

  if (error) {
    console.error('Error removing meal plan:', error);
    return false;
  }

  return true;
}

export async function clearAllMealPlans(): Promise<boolean> {
  const { error } = await supabase
    .from('meal_plans')
    .delete()
    .neq('id', '00000000-0000-0000-0000-000000000000');

  if (error) {
    console.error('Error clearing meal plans:', error);
    return false;
  }

  return true;
}

export async function bulkSetMealPlans(plans: { day: string; meal: string; recipeId: string }[]): Promise<boolean> {
  await clearAllMealPlans();

  const { error } = await supabase
    .from('meal_plans')
    .insert(plans.map(p => ({ day: p.day, meal: p.meal, recipe_id: p.recipeId })));

  if (error) {
    console.error('Error bulk setting meal plans:', error);
    return false;
  }

  return true;
}
