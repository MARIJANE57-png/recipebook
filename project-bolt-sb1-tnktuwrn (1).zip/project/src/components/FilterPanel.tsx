import { X, Star } from 'lucide-react';

interface FilterPanelProps {
  show: boolean;
  onClose: () => void;
  selectedCategories: string[];
  onCategoryChange: (categories: string[]) => void;
  selectedRating: number | null;
  onRatingChange: (rating: number | null) => void;
  showFavoritesOnly: boolean;
  onFavoritesChange: (show: boolean) => void;
}

const CATEGORIES = ['breakfast', 'lunch', 'dinner', 'snack', 'dessert', 'appetizer', 'beverage'];

export default function FilterPanel({
  show,
  onClose,
  selectedCategories,
  onCategoryChange,
  selectedRating,
  onRatingChange,
  showFavoritesOnly,
  onFavoritesChange,
}: FilterPanelProps) {
  if (!show) return null;

  const toggleCategory = (category: string) => {
    if (selectedCategories.includes(category)) {
      onCategoryChange(selectedCategories.filter(c => c !== category));
    } else {
      onCategoryChange([...selectedCategories, category]);
    }
  };

  return (
    <div
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        zIndex: 1000,
        display: 'flex',
        alignItems: 'flex-start',
        justifyContent: 'center',
        padding: '20px',
        paddingTop: '100px'
      }}
      onClick={onClose}
    >
      <div style={{
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: 'rgba(0, 0, 0, 0.5)',
        backdropFilter: 'blur(4px)'
      }} />

      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          position: 'relative',
          background: 'var(--bg-secondary)',
          borderRadius: '16px',
          maxWidth: '400px',
          width: '100%',
          padding: '24px',
          boxShadow: '0 8px 32px rgba(0, 0, 0, 0.12)',
          border: '1px solid var(--border-color)'
        }}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
          <h3 style={{
            fontFamily: "'Playfair Display', serif",
            fontSize: '24px',
            fontWeight: 600,
            color: 'var(--text-primary)',
            margin: 0
          }}>
            Filters
          </h3>
          <button
            onClick={onClose}
            style={{
              background: 'var(--bg-tertiary)',
              border: '1px solid var(--border-color)',
              borderRadius: '8px',
              padding: '8px',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: 'var(--text-primary)'
            }}
          >
            <X size={20} />
          </button>
        </div>

        <div style={{ marginBottom: '24px' }}>
          <h4 style={{
            fontSize: '14px',
            fontWeight: 600,
            color: 'var(--text-primary)',
            marginBottom: '12px',
            textTransform: 'uppercase',
            letterSpacing: '0.5px'
          }}>
            Categories
          </h4>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
            {CATEGORIES.map((category) => (
              <button
                key={category}
                onClick={() => toggleCategory(category)}
                style={{
                  padding: '8px 16px',
                  borderRadius: '20px',
                  border: '1px solid var(--border-color)',
                  background: selectedCategories.includes(category) ? 'var(--accent-color)' : 'var(--bg-tertiary)',
                  color: selectedCategories.includes(category) ? 'white' : 'var(--text-secondary)',
                  fontSize: '14px',
                  fontWeight: 500,
                  cursor: 'pointer',
                  transition: 'all 0.2s',
                  textTransform: 'capitalize'
                }}
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        <div style={{ marginBottom: '24px' }}>
          <h4 style={{
            fontSize: '14px',
            fontWeight: 600,
            color: 'var(--text-primary)',
            marginBottom: '12px',
            textTransform: 'uppercase',
            letterSpacing: '0.5px'
          }}>
            Minimum Rating
          </h4>
          <div style={{ display: 'flex', gap: '8px' }}>
            {[1, 2, 3, 4, 5].map((rating) => (
              <button
                key={rating}
                onClick={() => onRatingChange(selectedRating === rating ? null : rating)}
                style={{
                  padding: '8px 12px',
                  borderRadius: '8px',
                  border: '1px solid var(--border-color)',
                  background: selectedRating === rating ? 'var(--accent-color)' : 'var(--bg-tertiary)',
                  color: selectedRating === rating ? 'white' : 'var(--text-secondary)',
                  fontSize: '14px',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '4px',
                  transition: 'all 0.2s'
                }}
              >
                {rating}
                <Star size={14} fill={selectedRating === rating ? 'white' : 'none'} />
              </button>
            ))}
          </div>
        </div>

        <div>
          <label style={{
            display: 'flex',
            alignItems: 'center',
            gap: '12px',
            cursor: 'pointer',
            padding: '12px',
            borderRadius: '8px',
            background: 'var(--bg-tertiary)',
            border: '1px solid var(--border-color)'
          }}>
            <input
              type="checkbox"
              checked={showFavoritesOnly}
              onChange={(e) => onFavoritesChange(e.target.checked)}
              style={{
                width: '18px',
                height: '18px',
                cursor: 'pointer'
              }}
            />
            <span style={{
              fontSize: '14px',
              fontWeight: 500,
              color: 'var(--text-primary)'
            }}>
              Show favorites only
            </span>
          </label>
        </div>

        <button
          onClick={() => {
            onCategoryChange([]);
            onRatingChange(null);
            onFavoritesChange(false);
          }}
          style={{
            width: '100%',
            marginTop: '20px',
            padding: '12px',
            background: 'var(--bg-tertiary)',
            border: '1px solid var(--border-color)',
            borderRadius: '8px',
            color: 'var(--text-secondary)',
            fontSize: '14px',
            fontWeight: 600,
            cursor: 'pointer'
          }}
        >
          Clear All Filters
        </button>
      </div>
    </div>
  );
}
