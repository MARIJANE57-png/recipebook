import { useState, useEffect } from 'react';
import { Plus, Calendar as CalendarIcon, Printer } from 'lucide-react';
import { Recipe, MealPlan, ShoppingListItem } from '../types';
import { supabase } from '../lib/supabase';

export default function MealPlanView() {
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [mealPlans, setMealPlans] = useState<MealPlan[]>([]);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [showRecipeSelector, setShowRecipeSelector] = useState(false);
  const [selectedSlot, setSelectedSlot] = useState<{ date: string; mealType: string } | null>(null);
  const [dinnerOnlyMode, setDinnerOnlyMode] = useState(false);

  const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  const allMealTypes = ['breakfast', 'lunch', 'dinner', 'snack'];
  const mealTypes = dinnerOnlyMode ? ['dinner'] : allMealTypes;

  useEffect(() => {
    loadRecipes();
    loadMealPlans();
  }, [selectedDate]);

  const loadRecipes = async () => {
    try {
      const { data, error } = await supabase
        .from('recipes')
        .select('*')
        .order('title');

      if (error) throw error;
      setRecipes(data || []);
    } catch (error) {
      console.error('Error loading recipes:', error);
    }
  };

  const loadMealPlans = async () => {
    try {
      const startOfWeek = getStartOfWeek(selectedDate);
      const endOfWeek = new Date(startOfWeek);
      endOfWeek.setDate(endOfWeek.getDate() + 6);

      const { data, error } = await supabase
        .from('meal_plans')
        .select('*, recipe:recipes(*)')
        .gte('date', startOfWeek.toISOString().split('T')[0])
        .lte('date', endOfWeek.toISOString().split('T')[0]);

      if (error) throw error;
      setMealPlans(data || []);
    } catch (error) {
      console.error('Error loading meal plans:', error);
    }
  };

  const getStartOfWeek = (date: Date) => {
    const d = new Date(date);
    const day = d.getDay();
    const diff = d.getDate() - day + (day === 0 ? -6 : 1);
    return new Date(d.setDate(diff));
  };

  const getDateForDay = (dayIndex: number) => {
    const startOfWeek = getStartOfWeek(selectedDate);
    const date = new Date(startOfWeek);
    date.setDate(date.getDate() + dayIndex);
    return date.toISOString().split('T')[0];
  };

  const getMealForSlot = (dayIndex: number, mealType: string) => {
    const date = getDateForDay(dayIndex);
    return mealPlans.find((plan) => plan.date === date && plan.meal_type === mealType);
  };

  const handleAddMeal = (dayIndex: number, mealType: string) => {
    const date = getDateForDay(dayIndex);
    setSelectedSlot({ date, mealType });
    setShowRecipeSelector(true);
  };

  const handleSelectRecipe = async (recipeId: string) => {
    if (!selectedSlot) return;

    try {
      const dayOfWeek = daysOfWeek[new Date(selectedSlot.date).getDay() === 0 ? 6 : new Date(selectedSlot.date).getDay() - 1];

      const { error } = await supabase
        .from('meal_plans')
        .insert([{
          recipe_id: recipeId,
          date: selectedSlot.date,
          day: dayOfWeek,
          meal_type: selectedSlot.mealType,
          servings: 4,
        }]);

      if (error) throw error;
      await loadMealPlans();
      setShowRecipeSelector(false);
      setSelectedSlot(null);
    } catch (error) {
      console.error('Error adding meal:', error);
    }
  };

  const handleRemoveMeal = async (mealPlanId: string) => {
    try {
      const { error } = await supabase
        .from('meal_plans')
        .delete()
        .eq('id', mealPlanId);

      if (error) throw error;
      await loadMealPlans();
    } catch (error) {
      console.error('Error removing meal:', error);
    }
  };

  const goToPreviousWeek = () => {
    const newDate = new Date(selectedDate);
    newDate.setDate(newDate.getDate() - 7);
    setSelectedDate(newDate);
  };

  const goToNextWeek = () => {
    const newDate = new Date(selectedDate);
    newDate.setDate(newDate.getDate() + 7);
    setSelectedDate(newDate);
  };

  const goToCurrentWeek = () => {
    setSelectedDate(new Date());
  };

  const handlePrintMealPlanWithShoppingList = async () => {
    try {
      console.log('Print function started');
      const startOfWeek = getStartOfWeek(selectedDate);
      const endOfWeek = new Date(startOfWeek);
      endOfWeek.setDate(endOfWeek.getDate() + 6);

      console.log('Fetching shopping list...');
      const { data: shoppingListData, error: shoppingError } = await supabase
        .from('shopping_list_items')
        .select('*')
        .order('checked', { ascending: true });

      if (shoppingError) {
        console.error('Shopping list error:', shoppingError);
        throw shoppingError;
      }

      console.log('Shopping list data:', shoppingListData);
      const uncheckedItems = (shoppingListData || []).filter(item => !item.checked);
      const checkedItems = (shoppingListData || []).filter(item => item.checked);
      console.log('Unchecked items:', uncheckedItems.length, 'Checked items:', checkedItems.length);

      const dateRangeText = formatDateRange();

      const daysHeaders = daysOfWeek.map((day, index) => {
        const date = new Date(getDateForDay(index));
        return `<th>${day}<br><span style="font-size: 12px; font-weight: 400; color: #6b7c63;">${date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span></th>`;
      }).join('');

      const mealRows = mealTypes.map(mealType => {
        const dayCells = daysOfWeek.map((_, dayIndex) => {
          const meal = getMealForSlot(dayIndex, mealType);
          return `
            <td>
              ${meal ? `
                <div class="recipe-title">${meal.recipe?.title || 'N/A'}</div>
                ${meal.recipe?.prep_time ? `<div class="recipe-time">${meal.recipe.prep_time} min</div>` : ''}
              ` : '<div class="empty-slot">-</div>'}
            </td>
          `;
        }).join('');

        return `
          <tr>
            <td class="meal-type">${mealType}</td>
            ${dayCells}
          </tr>
        `;
      }).join('');

      const uncheckedItemsHtml = uncheckedItems.length > 0 ? `
        <div style="margin-bottom: 20px;">
          <h3 style="font-size: 18px; margin-bottom: 12px; color: #2d3a2e;">To Buy (${uncheckedItems.length} items)</h3>
          ${uncheckedItems.map((item: ShoppingListItem) => `
            <div class="shopping-list-item">
              <div class="checkbox"></div>
              <span class="item-name">${item.ingredient_name}</span>
              ${item.quantity ? `<span class="item-quantity">${item.quantity}</span>` : ''}
            </div>
          `).join('')}
        </div>
      ` : '<p style="color: #6b7c63; font-style: italic;">No items in shopping list</p>';

      const checkedItemsHtml = checkedItems.length > 0 ? `
        <div class="checked-section">
          <h3 style="font-size: 18px; margin-bottom: 12px; color: #2d3a2e;">Checked Off (${checkedItems.length} items)</h3>
          ${checkedItems.map((item: ShoppingListItem) => `
            <div class="shopping-list-item checked-item">
              <div class="checkbox" style="background: #8b9d83;"></div>
              <span class="item-name">${item.ingredient_name}</span>
              ${item.quantity ? `<span class="item-quantity">${item.quantity}</span>` : ''}
            </div>
          `).join('')}
        </div>
      ` : '';

      console.log('Creating print content...');

      const printContent = `
        <!DOCTYPE html>
        <html>
          <head>
            <title>Meal Plan & Shopping List</title>
            <style>
              @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Montserrat:wght@300;400;500;600&display=swap');

              * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
              }

              body {
                font-family: 'Montserrat', sans-serif;
                padding: 40px;
                color: #2d3a2e;
                max-width: 1000px;
                margin: 0 auto;
              }

              h1 {
                font-family: 'Playfair Display', serif;
                font-size: 32px;
                font-weight: 600;
                margin-bottom: 8px;
                color: #2d3a2e;
              }

              .subtitle {
                font-size: 16px;
                color: #6b7c63;
                margin-bottom: 32px;
              }

              .section {
                margin-bottom: 40px;
                page-break-inside: avoid;
              }

              h2 {
                font-family: 'Playfair Display', serif;
                font-size: 24px;
                font-weight: 600;
                margin-bottom: 20px;
                color: #2d3a2e;
                border-bottom: 2px solid #8b9d83;
                padding-bottom: 8px;
              }

              table {
                width: 100%;
                border-collapse: collapse;
                margin-bottom: 24px;
              }

              th {
                background: #f5f5f5;
                padding: 12px;
                text-align: left;
                font-weight: 600;
                color: #2d3a2e;
                border: 1px solid #e5e7eb;
              }

              td {
                padding: 12px;
                border: 1px solid #e5e7eb;
                vertical-align: top;
              }

              .meal-type {
                font-weight: 600;
                text-transform: capitalize;
                background: #f9fafb;
              }

              .recipe-title {
                font-weight: 500;
                color: #2d3a2e;
                margin-bottom: 4px;
              }

              .recipe-time {
                font-size: 12px;
                color: #6b7c63;
              }

              .empty-slot {
                color: #9ca3af;
                font-style: italic;
              }

              .shopping-list-item {
                display: flex;
                padding: 8px 0;
                border-bottom: 1px solid #e5e7eb;
              }

              .checkbox {
                width: 18px;
                height: 18px;
                border: 2px solid #8b9d83;
                margin-right: 12px;
                flex-shrink: 0;
                border-radius: 3px;
              }

              .item-name {
                font-weight: 500;
                flex: 1;
              }

              .item-quantity {
                color: #6b7c63;
                margin-left: 10px;
              }

              .checked-section {
                margin-top: 20px;
                opacity: 0.6;
              }

              .checked-item {
                text-decoration: line-through;
              }

              @media print {
                body {
                  padding: 20px;
                }
                .section {
                  page-break-inside: avoid;
                }
                .print-button {
                  display: none;
                }
              }

              .print-button {
                position: fixed;
                top: 20px;
                right: 20px;
                background: #8b9d83;
                color: white;
                border: none;
                padding: 12px 24px;
                border-radius: 8px;
                font-family: 'Montserrat', sans-serif;
                font-weight: 500;
                cursor: pointer;
                box-shadow: 0 2px 8px rgba(0,0,0,0.1);
                font-size: 14px;
                z-index: 1000;
              }

              .print-button:hover {
                background: #7a8c74;
              }
            </style>
          </head>
          <body>
            <button class="print-button" onclick="window.print()">Print</button>
            <h1>Meal Plan & Shopping List</h1>
            <p class="subtitle">${dateRangeText}</p>

            <div class="section">
              <h2>Weekly Meal Plan</h2>
              <table>
                <thead>
                  <tr>
                    <th style="width: 120px;">Meal</th>
                    ${daysHeaders}
                  </tr>
                </thead>
                <tbody>
                  ${mealRows}
                </tbody>
              </table>
            </div>

            <div class="section">
              <h2>Shopping List</h2>
              ${uncheckedItemsHtml}
              ${checkedItemsHtml}
            </div>
          </body>
        </html>
      `;

      console.log('Creating blob and opening...');
      const blob = new Blob([printContent], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      const printWindow = window.open(url, '_blank');

      if (!printWindow) {
        alert('Please allow popups to print the meal plan');
        URL.revokeObjectURL(url);
        return;
      }

      printWindow.onload = () => {
        setTimeout(() => {
          console.log('Triggering print dialog...');
          printWindow.print();
          setTimeout(() => {
            URL.revokeObjectURL(url);
          }, 100);
        }, 250);
      };
    } catch (error) {
      console.error('Error printing meal plan with shopping list:', error);
      alert('Error printing: ' + error.message);
    }
  };

  const formatDateRange = () => {
    const start = getStartOfWeek(selectedDate);
    const end = new Date(start);
    end.setDate(end.getDate() + 6);
    return `${start.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - ${end.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}`;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-3xl font-bold text-gray-900">Meal Planner</h2>
          <div className="flex items-center gap-4">
            <button
              onClick={handlePrintMealPlanWithShoppingList}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                padding: '8px 16px',
                background: 'color-mix(in srgb, #8b9d83 15%, transparent)',
                color: '#6b7c63',
                border: '1px solid #8b9d83',
                borderRadius: '8px',
                fontSize: '14px',
                fontWeight: 500,
                cursor: 'pointer',
                transition: 'all 0.2s'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = '#8b9d83';
                e.currentTarget.style.color = 'white';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = 'color-mix(in srgb, #8b9d83 15%, transparent)';
                e.currentTarget.style.color = '#6b7c63';
              }}
              title="Print meal plan with shopping list"
            >
              <Printer size={16} />
              Print Meal Plan & Shopping List
            </button>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={dinnerOnlyMode}
                onChange={(e) => setDinnerOnlyMode(e.target.checked)}
                className="w-4 h-4 text-sage-600 rounded"
              />
              <span className="text-sm font-medium text-gray-700">Dinner Only</span>
            </label>
          </div>
        </div>

        <div className="flex items-center justify-between bg-white rounded-lg shadow-sm p-4">
          <button
            onClick={goToPreviousWeek}
            className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
          >
            ← Previous
          </button>

          <div className="flex items-center gap-3">
            <CalendarIcon className="w-5 h-5 text-gray-600" />
            <span className="font-medium text-gray-900">{formatDateRange()}</span>
            <button
              onClick={goToCurrentWeek}
              style={{
                padding: '4px 12px',
                fontSize: '14px',
                background: 'color-mix(in srgb, #8b9d83 20%, transparent)',
                color: '#8b9d83',
                borderRadius: '8px',
                border: 'none',
                cursor: 'pointer',
                fontWeight: 500,
                transition: 'all 0.2s'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = 'color-mix(in srgb, #8b9d83 30%, transparent)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = 'color-mix(in srgb, #8b9d83 20%, transparent)';
              }}
            >
              Today
            </button>
          </div>

          <button
            onClick={goToNextWeek}
            className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
          >
            Next →
          </button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="grid grid-cols-8 border-b">
          <div className="p-4 bg-gray-50 font-medium text-gray-700 border-r">Meal</div>
          {daysOfWeek.map((day, index) => (
            <div key={day} className="p-4 bg-gray-50 font-medium text-gray-700 text-center border-r last:border-r-0">
              <div>{day}</div>
              <div className="text-xs text-gray-500 mt-1">
                {new Date(getDateForDay(index)).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
              </div>
            </div>
          ))}
        </div>

        {mealTypes.map((mealType) => (
          <div key={mealType} className="grid grid-cols-8 border-b last:border-b-0">
            <div className="p-4 bg-gray-50 border-r font-medium text-gray-700 capitalize flex items-center">
              {mealType}
            </div>
            {daysOfWeek.map((_, dayIndex) => {
              const meal = getMealForSlot(dayIndex, mealType);
              return (
                <div key={dayIndex} className="p-2 border-r last:border-r-0 min-h-[100px]">
                  {meal ? (
                    <div style={{
                      background: 'color-mix(in srgb, #8b9d83 15%, transparent)',
                      borderRadius: '8px',
                      padding: '12px',
                      height: '100%',
                      transition: 'all 0.2s',
                      position: 'relative'
                    }}
                    className="group"
                    onMouseEnter={(e) => {
                      e.currentTarget.style.background = 'color-mix(in srgb, #8b9d83 25%, transparent)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.background = 'color-mix(in srgb, #8b9d83 15%, transparent)';
                    }}>
                      <div className="text-sm font-medium mb-1" style={{ color: '#2d3a2e' }}>
                        {meal.recipe?.title}
                      </div>
                      <div className="text-xs" style={{ color: '#6b7c63' }}>
                        {meal.recipe?.prep_time && `${meal.recipe.prep_time} min`}
                      </div>
                      <button
                        onClick={() => handleRemoveMeal(meal.id)}
                        className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity text-red-600 hover:text-red-700"
                      >
                        ×
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => handleAddMeal(dayIndex, mealType)}
                      className="w-full h-full flex items-center justify-center rounded-lg transition-colors"
                      style={{ color: '#9ca3af' }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.color = '#8b9d83';
                        e.currentTarget.style.background = 'color-mix(in srgb, #8b9d83 10%, transparent)';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.color = '#9ca3af';
                        e.currentTarget.style.background = 'transparent';
                      }}
                    >
                      <Plus className="w-5 h-5" />
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        ))}
      </div>

      {showRecipeSelector && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[80vh] overflow-hidden">
            <div className="p-6 border-b">
              <h3 className="text-xl font-bold text-gray-900">Select a Recipe</h3>
            </div>
            <div className="overflow-y-auto max-h-[60vh] p-6">
              <div className="grid grid-cols-1 gap-3">
                {recipes.map((recipe) => (
                  <button
                    key={recipe.id}
                    onClick={() => handleSelectRecipe(recipe.id)}
                    className="text-left p-4 border border-gray-200 rounded-lg transition-colors"
                    onMouseEnter={(e) => {
                      e.currentTarget.style.borderColor = '#8b9d83';
                      e.currentTarget.style.background = 'color-mix(in srgb, #8b9d83 10%, transparent)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.borderColor = '#e5e7eb';
                      e.currentTarget.style.background = 'transparent';
                    }}
                  >
                    <div className="font-medium text-gray-900">{recipe.title}</div>
                    <div className="text-sm text-gray-500 mt-1">
                      {recipe.category} • {recipe.prep_time || '0'} + {recipe.cook_time || '0'} min • {recipe.servings} servings
                    </div>
                  </button>
                ))}
              </div>
            </div>
            <div className="p-6 border-t">
              <button
                onClick={() => {
                  setShowRecipeSelector(false);
                  setSelectedSlot(null);
                }}
                className="w-full px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
