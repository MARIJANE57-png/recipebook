import { useState, useEffect } from 'react';
import { Menu, X, Plus, Trash2, Download, Sparkles, Star, Printer } from 'lucide-react';
import { Recipe } from '../types';
import { supabase } from '../lib/supabase';
import RecipeForm from '../components/RecipeForm';
import ImportModal from '../components/ImportModal';
import AIRecommendationModal from '../components/AIRecommendationModal';
import FilterPanel from '../components/FilterPanel';

export default function RecipesView() {
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [filteredRecipes, setFilteredRecipes] = useState<Recipe[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [selectedRating, setSelectedRating] = useState<number | null>(null);
  const [showFavoritesOnly, setShowFavoritesOnly] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [showImport, setShowImport] = useState(false);
  const [showAIRecommend, setShowAIRecommend] = useState(false);
  const [editingRecipe, setEditingRecipe] = useState<Recipe | undefined>();
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadRecipes();
  }, []);

  useEffect(() => {
    filterRecipes();
  }, [recipes, searchTerm, selectedCategories, selectedRating, showFavoritesOnly]);

  const loadRecipes = async () => {
    try {
      const { data, error } = await supabase
        .from('recipes')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setRecipes(data || []);
    } catch (error) {
      console.error('Error loading recipes:', error);
    } finally {
      setLoading(false);
    }
  };

  const filterRecipes = () => {
    let filtered = recipes;

    if (searchTerm) {
      filtered = filtered.filter((recipe) =>
        recipe.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        recipe.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (recipe.tags && recipe.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase())))
      );
    }

    if (selectedCategories.length > 0) {
      filtered = filtered.filter((recipe) =>
        selectedCategories.includes(recipe.category)
      );
    }

    if (selectedRating !== null) {
      filtered = filtered.filter((recipe) =>
        recipe.rating && recipe.rating >= selectedRating
      );
    }

    if (showFavoritesOnly) {
      filtered = filtered.filter((recipe) => recipe.favorite);
    }

    setFilteredRecipes(filtered);
  };

  const handleSave = async (recipeData: Partial<Recipe>) => {
    try {
      if (editingRecipe) {
        const { error } = await supabase
          .from('recipes')
          .update({ ...recipeData, updated_at: new Date().toISOString() })
          .eq('id', editingRecipe.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from('recipes').insert([recipeData]);
        if (error) throw error;
      }
      await loadRecipes();
      setShowForm(false);
      setEditingRecipe(undefined);
    } catch (error) {
      console.error('Error saving recipe:', error);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this recipe?')) return;
    try {
      const { error } = await supabase.from('recipes').delete().eq('id', id);
      if (error) throw error;
      setSelectedRecipe(null);
      await loadRecipes();
    } catch (error) {
      console.error('Error deleting recipe:', error);
    }
  };

  const handleToggleFavorite = async (id: string, favorite: boolean) => {
    try {
      const { error } = await supabase.from('recipes').update({ favorite }).eq('id', id);
      if (error) throw error;
      await loadRecipes();
    } catch (error) {
      console.error('Error updating favorite:', error);
    }
  };

  const handleImport = async (recipeData: Partial<Recipe>) => {
    try {
      const { error } = await supabase.from('recipes').insert([recipeData]);
      if (error) throw error;
      await loadRecipes();
      setShowImport(false);
    } catch (error) {
      console.error('Error importing recipe:', error);
    }
  };

  const handleAIRecommend = async (recipeData: Partial<Recipe>) => {
    try {
      const { error } = await supabase.from('recipes').insert([recipeData]);
      if (error) throw error;
      await loadRecipes();
      setShowAIRecommend(false);
    } catch (error) {
      console.error('Error saving AI recommendation:', error);
    }
  };

  const handlePrintRecipe = (recipe: Recipe) => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>${recipe.title}</title>
          <style>
            @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Montserrat:wght@300;400;500;600&display=swap');

            * {
              margin: 0;
              padding: 0;
              box-sizing: border-box;
            }

            body {
              font-family: 'Montserrat', sans-serif;
              padding: 40px;
              color: #2d3a2e;
              max-width: 800px;
              margin: 0 auto;
            }

            h1 {
              font-family: 'Playfair Display', serif;
              font-size: 32px;
              font-weight: 600;
              margin-bottom: 12px;
              color: #2d3a2e;
            }

            .description {
              font-size: 16px;
              color: #6b7c63;
              margin-bottom: 24px;
              line-height: 1.6;
            }

            .meta {
              display: flex;
              gap: 20px;
              margin-bottom: 32px;
              padding: 16px;
              background: #f5f5f5;
              border-radius: 8px;
            }

            .meta-item {
              font-size: 14px;
            }

            .meta-label {
              font-weight: 600;
              color: #2d3a2e;
            }

            .meta-value {
              color: #6b7c63;
              text-transform: capitalize;
            }

            h2 {
              font-family: 'Playfair Display', serif;
              font-size: 22px;
              font-weight: 600;
              margin: 32px 0 16px 0;
              color: #2d3a2e;
              border-bottom: 2px solid #8b9d83;
              padding-bottom: 8px;
            }

            .ingredient {
              display: flex;
              gap: 12px;
              margin-bottom: 12px;
              line-height: 1.6;
            }

            .ingredient-bullet {
              color: #8b9d83;
              font-size: 20px;
              line-height: 1;
            }

            .instruction {
              display: flex;
              gap: 12px;
              margin-bottom: 16px;
              line-height: 1.6;
            }

            .instruction-number {
              color: #8b9d83;
              font-weight: 600;
              min-width: 24px;
            }

            @media print {
              body {
                padding: 20px;
              }
            }
          </style>
        </head>
        <body>
          <h1>${recipe.title}</h1>
          <p class="description">${recipe.description || ''}</p>

          <div class="meta">
            ${recipe.category ? `<div class="meta-item"><span class="meta-label">Category:</span> <span class="meta-value">${recipe.category}</span></div>` : ''}
            ${recipe.prep_time ? `<div class="meta-item"><span class="meta-label">Prep:</span> <span class="meta-value">${recipe.prep_time} min</span></div>` : ''}
            ${recipe.cook_time ? `<div class="meta-item"><span class="meta-label">Cook:</span> <span class="meta-value">${recipe.cook_time} min</span></div>` : ''}
            ${recipe.servings ? `<div class="meta-item"><span class="meta-label">Servings:</span> <span class="meta-value">${recipe.servings}</span></div>` : ''}
          </div>

          <h2>Ingredients</h2>
          <div>
            ${(recipe.ingredients || []).map((ing: any) => `
              <div class="ingredient">
                <span class="ingredient-bullet">•</span>
                <span>${ing.amount} ${ing.item}</span>
              </div>
            `).join('')}
          </div>

          <h2>Instructions</h2>
          <div>
            ${(recipe.instructions || []).map((inst: any, i: number) => `
              <div class="instruction">
                <span class="instruction-number">${i + 1}.</span>
                <span>${inst.text}</span>
              </div>
            `).join('')}
          </div>

          ${recipe.notes ? `
            <h2>Notes</h2>
            <p style="line-height: 1.6;">${recipe.notes}</p>
          ` : ''}
        </body>
      </html>
    `);

    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
      printWindow.print();
    }, 250);
  };

  if (loading) {
    return <div style={{ textAlign: 'center', padding: '40px', color: '#a8a8a8' }}>Loading...</div>;
  }

  return (
    <div style={{ maxWidth: '900px', margin: '0 auto', position: 'relative' }}>
      <main style={{ padding: '32px 20px', minHeight: 'calc(100vh - 140px)' }}>
        <section style={{ marginBottom: '32px' }}>
          <div style={{ marginBottom: '20px', textAlign: 'center' }}>
            <p style={{ fontSize: '14px', color: 'var(--text-secondary)' }}>
              <span>{filteredRecipes.length}</span> of <span>{recipes.length}</span> recipes
              {(selectedCategories.length > 0 || selectedRating || showFavoritesOnly) && ' (filtered)'}
            </p>
          </div>

          <div style={{ position: 'relative', display: 'flex', gap: '12px', alignItems: 'center' }}>
            <div style={{ flex: 1 }}>
              <input
                type="text"
                placeholder="Search recipes by name, tag, or ingredient..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                style={{
                  width: '100%',
                  padding: '14px 18px',
                  fontSize: '15px',
                  fontFamily: "'Montserrat', sans-serif",
                  background: 'var(--bg-tertiary)',
                  border: '1px solid var(--border-color)',
                  borderRadius: '12px',
                  color: 'var(--text-primary)',
                  outline: 'none'
                }}
              />
            </div>
            <button
              onClick={() => setShowFilters(!showFilters)}
              style={{
                padding: '12px',
                background: showFilters || selectedCategories.length > 0 || selectedRating || showFavoritesOnly ? 'var(--accent-color)' : 'var(--bg-tertiary)',
                border: '1px solid var(--border-color)',
                borderRadius: '12px',
                cursor: 'pointer',
                color: showFilters || selectedCategories.length > 0 || selectedRating || showFavoritesOnly ? 'white' : 'var(--text-primary)',
                transition: 'all 0.3s'
              }}
            >
              <Menu style={{ width: 24, height: 24 }} />
            </button>
          </div>
        </section>

        <section>
          {filteredRecipes.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '48px 20px', color: 'var(--text-secondary)' }}>
              <h3 style={{ fontFamily: "'Playfair Display', serif", fontSize: '24px', color: 'var(--text-primary)', marginBottom: '12px' }}>
                No recipes found
              </h3>
              <p style={{ fontSize: '15px', color: 'var(--text-secondary)' }}>
                {searchTerm || selectedCategories.length > 0 || selectedRating || showFavoritesOnly ? 'Try adjusting your filters' : (
                  <>Add your first recipe with the <button onClick={() => setShowForm(true)} style={{ color: 'var(--accent-color)', background: 'none', border: 'none', fontWeight: 600, cursor: 'pointer', textDecoration: 'underline' }}>+ button</button></>
                )}
              </p>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
              {filteredRecipes.map((recipe) => (
                <div
                  key={recipe.id}
                  onClick={() => setSelectedRecipe(recipe)}
                  style={{
                    display: 'flex',
                    gap: '20px',
                    background: 'var(--bg-secondary)',
                    border: '1px solid var(--border-color)',
                    borderRadius: '16px',
                    padding: '20px',
                    cursor: 'pointer',
                    transition: 'all 0.3s'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = 'translateY(-2px)';
                    e.currentTarget.style.boxShadow = '0 8px 32px rgba(0, 0, 0, 0.12)';
                    e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.2)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = 'translateY(0)';
                    e.currentTarget.style.boxShadow = 'none';
                    e.currentTarget.style.borderColor = 'var(--border-color)';
                  }}
                >
                  <div style={{
                    flexShrink: 0,
                    width: '120px',
                    height: '120px',
                    borderRadius: '12px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    background: '#000000'
                  }}>
                    <div style={{
                      fontFamily: "'Playfair Display', serif",
                      fontSize: '16px',
                      fontWeight: 600,
                      color: 'white',
                      textAlign: 'center',
                      lineHeight: 1.3
                    }}>
                      Recipe<br/>Society
                    </div>
                  </div>

                  <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'space-between', minWidth: 0 }}>
                    <div>
                      <h3 style={{
                        fontFamily: "'Playfair Display', serif",
                        fontSize: '20px',
                        fontWeight: 600,
                        color: 'var(--text-primary)',
                        marginBottom: '8px',
                        lineHeight: 1.3,
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                        display: '-webkit-box',
                        WebkitLineClamp: 2,
                        WebkitBoxOrient: 'vertical'
                      }}>
                        {recipe.title}
                      </h3>
                      <p style={{
                        fontSize: '14px',
                        color: 'var(--text-secondary)',
                        marginBottom: '12px',
                        lineHeight: 1.5,
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                        display: '-webkit-box',
                        WebkitLineClamp: 2,
                        WebkitBoxOrient: 'vertical'
                      }}>
                        {recipe.description}
                      </p>
                    </div>

                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '8px' }}>
                      <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                        <span style={{
                          fontSize: '12px',
                          padding: '4px 12px',
                          background: 'color-mix(in srgb, #8b9d83 20%, transparent)',
                          color: '#8b9d83',
                          borderRadius: '100px',
                          fontWeight: 600,
                          textTransform: 'capitalize'
                        }}>
                          {recipe.category || 'Recipe'}
                        </span>
                        {recipe.rating && (
                          <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                size={14}
                                fill={i < recipe.rating! ? '#fbbf24' : 'none'}
                                stroke={i < recipe.rating! ? '#fbbf24' : 'var(--text-secondary)'}
                              />
                            ))}
                          </div>
                        )}
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleToggleFavorite(recipe.id, !recipe.favorite);
                        }}
                        style={{
                          background: 'none',
                          border: 'none',
                          fontSize: '20px',
                          cursor: 'pointer',
                          padding: '4px 8px',
                          transition: 'transform 0.2s'
                        }}
                      >
                        {recipe.favorite ? '❤️' : '🤍'}
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      </main>

      <div style={{ position: 'fixed', bottom: '100px', right: '20px', display: 'flex', flexDirection: 'column', gap: '12px', zIndex: 50 }}>
        <button
          onClick={() => setShowAIRecommend(true)}
          style={{
            width: '56px',
            height: '56px',
            borderRadius: '50%',
            background: 'linear-gradient(135deg, #9aae92 0%, #8b9d83 100%)',
            border: 'none',
            color: 'white',
            fontSize: '24px',
            cursor: 'pointer',
            boxShadow: '0 4px 16px rgba(139, 157, 131, 0.4)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            transition: 'all 0.3s'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.transform = 'scale(1.1)';
            e.currentTarget.style.boxShadow = '0 8px 24px rgba(139, 157, 131, 0.5)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = 'scale(1)';
            e.currentTarget.style.boxShadow = '0 4px 16px rgba(139, 157, 131, 0.4)';
          }}
          title="AI Recipe Recommendation"
        >
          <Sparkles />
        </button>
        <button
          onClick={() => setShowImport(true)}
          style={{
            width: '56px',
            height: '56px',
            borderRadius: '50%',
            background: '#6b7c63',
            border: 'none',
            color: 'white',
            fontSize: '24px',
            cursor: 'pointer',
            boxShadow: '0 4px 16px rgba(0, 0, 0, 0.3)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            transition: 'all 0.3s'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.transform = 'scale(1.1)';
            e.currentTarget.style.background = '#7a8d72';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = 'scale(1)';
            e.currentTarget.style.background = '#6b7c63';
          }}
          title="Import Recipe"
        >
          <Download />
        </button>
        <button
          onClick={() => setShowForm(true)}
          style={{
            width: '56px',
            height: '56px',
            borderRadius: '50%',
            background: '#8b9d83',
            border: 'none',
            color: 'white',
            fontSize: '24px',
            cursor: 'pointer',
            boxShadow: '0 4px 16px rgba(0, 0, 0, 0.3)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            transition: 'all 0.3s'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.transform = 'scale(1.1)';
            e.currentTarget.style.background = '#9aae92';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = 'scale(1)';
            e.currentTarget.style.background = '#8b9d83';
          }}
        >
          <Plus />
        </button>
      </div>

      {selectedRecipe && (
        <div
          style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            zIndex: 1000,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '20px'
          }}
          onClick={() => setSelectedRecipe(null)}
        >
          <div style={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: 'rgba(0, 0, 0, 0.85)',
            backdropFilter: 'blur(4px)'
          }} />
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              position: 'relative',
              background: 'var(--bg-secondary)',
              borderRadius: '24px',
              maxWidth: '700px',
              width: '100%',
              maxHeight: '90vh',
              overflowY: 'auto',
              boxShadow: '0 8px 32px rgba(0, 0, 0, 0.12)',
              border: '1px solid var(--border-color)'
            }}
          >
            <button
              onClick={() => setSelectedRecipe(null)}
              style={{
                position: 'sticky',
                top: '20px',
                right: '20px',
                float: 'right',
                background: 'var(--bg-tertiary)',
                border: '1px solid var(--border-color)',
                width: '36px',
                height: '36px',
                borderRadius: '50%',
                fontSize: '24px',
                color: 'var(--text-primary)',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                zIndex: 10,
                margin: '20px 20px 0 0',
                transition: 'all 0.2s'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = 'var(--bg-primary)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = 'var(--bg-tertiary)';
              }}
            >
              <X />
            </button>
            <div style={{ padding: '48px', paddingTop: 0 }}>
              <h2 style={{
                fontFamily: "'Playfair Display', serif",
                fontSize: '32px',
                fontWeight: 600,
                color: 'var(--text-primary)',
                marginBottom: '12px',
                lineHeight: 1.2
              }}>
                {selectedRecipe.title}
              </h2>
              <p style={{ fontSize: '16px', color: 'var(--text-secondary)', marginBottom: '20px', lineHeight: 1.6 }}>
                {selectedRecipe.description}
              </p>

              <div style={{ marginBottom: '32px' }}>
                <h3 style={{
                  fontFamily: "'Playfair Display', serif",
                  fontSize: '22px',
                  color: 'var(--text-primary)',
                  marginBottom: '20px'
                }}>
                  Ingredients
                </h3>
                <div style={{ paddingLeft: '8px' }}>
                  {(selectedRecipe.ingredients || []).map((ing: any, i: number) => (
                    <div key={i} style={{ marginBottom: '12px', color: 'var(--text-secondary)', lineHeight: 1.6, display: 'flex', gap: '12px', alignItems: 'baseline' }}>
                      <span style={{ color: '#8b9d83', fontSize: '20px', lineHeight: 1 }}>•</span>
                      <span>{ing.amount} {ing.item}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div style={{ marginBottom: '32px' }}>
                <h3 style={{
                  fontFamily: "'Playfair Display', serif",
                  fontSize: '22px',
                  color: 'var(--text-primary)',
                  marginBottom: '20px'
                }}>
                  Instructions
                </h3>
                <div style={{ paddingLeft: '8px' }}>
                  {(selectedRecipe.instructions || []).map((inst: any, i: number) => (
                    <div key={i} style={{ marginBottom: '16px', color: 'var(--text-secondary)', lineHeight: 1.6, display: 'flex', gap: '12px' }}>
                      <span style={{ color: '#8b9d83', fontSize: '16px', fontWeight: 600, minWidth: '24px' }}>{i + 1}.</span>
                      <span>{inst.text}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div style={{
                display: 'flex',
                gap: '12px',
                paddingTop: '20px',
                borderTop: '1px solid var(--border-color)'
              }}>
                <button
                  onClick={() => handlePrintRecipe(selectedRecipe)}
                  style={{
                    padding: '14px 24px',
                    background: 'var(--bg-tertiary)',
                    color: 'var(--text-primary)',
                    border: '1px solid var(--border-color)',
                    borderRadius: '12px',
                    fontWeight: 600,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    transition: 'all 0.2s'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = '#8b9d83';
                    e.currentTarget.style.color = 'white';
                    e.currentTarget.style.borderColor = '#8b9d83';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = 'var(--bg-tertiary)';
                    e.currentTarget.style.color = 'var(--text-primary)';
                    e.currentTarget.style.borderColor = 'var(--border-color)';
                  }}
                >
                  <Printer style={{ width: 18, height: 18 }} />
                  Print
                </button>
                <button
                  onClick={() => {
                    setEditingRecipe(selectedRecipe);
                    setSelectedRecipe(null);
                    setShowForm(true);
                  }}
                  style={{
                    flex: 1,
                    padding: '14px 24px',
                    background: '#8b9d83',
                    color: 'white',
                    textAlign: 'center',
                    border: 'none',
                    borderRadius: '12px',
                    fontWeight: 600,
                    cursor: 'pointer'
                  }}
                >
                  Edit Recipe
                </button>
                <button
                  onClick={() => handleDelete(selectedRecipe.id)}
                  style={{
                    padding: '14px 24px',
                    background: 'rgba(220, 38, 38, 0.2)',
                    color: '#ef4444',
                    border: '1px solid rgba(220, 38, 38, 0.3)',
                    borderRadius: '12px',
                    fontWeight: 600,
                    cursor: 'pointer'
                  }}
                >
                  <Trash2 style={{ width: 20, height: 20 }} />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {showForm && (
        <RecipeForm
          recipe={editingRecipe}
          onSave={handleSave}
          onCancel={() => {
            setShowForm(false);
            setEditingRecipe(undefined);
          }}
        />
      )}

      {showImport && (
        <ImportModal
          onImport={handleImport}
          onCancel={() => setShowImport(false)}
        />
      )}

      {showAIRecommend && (
        <AIRecommendationModal
          onRecommend={handleAIRecommend}
          onCancel={() => setShowAIRecommend(false)}
        />
      )}

      <FilterPanel
        show={showFilters}
        onClose={() => setShowFilters(false)}
        selectedCategories={selectedCategories}
        onCategoryChange={setSelectedCategories}
        selectedRating={selectedRating}
        onRatingChange={setSelectedRating}
        showFavoritesOnly={showFavoritesOnly}
        onFavoritesChange={setShowFavoritesOnly}
      />
    </div>
  );
}
