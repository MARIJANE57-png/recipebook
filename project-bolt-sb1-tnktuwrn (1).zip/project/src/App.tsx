import { useState } from 'react';
import Navigation from './components/Navigation';
import RecipesView from './views/RecipesView';
import MealPlanView from './views/MealPlanView';
import ShoppingListView from './views/ShoppingListView';

function App() {
  const [currentView, setCurrentView] = useState<'recipes' | 'meal-plan' | 'shopping'>('recipes');

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg-primary)', paddingBottom: '70px' }}>
      <Navigation currentView={currentView} onViewChange={setCurrentView} />
      <main>
        {currentView === 'recipes' && <RecipesView />}
        {currentView === 'meal-plan' && <MealPlanView />}
        {currentView === 'shopping' && <ShoppingListView />}
      </main>
    </div>
  );
}

export default App;
