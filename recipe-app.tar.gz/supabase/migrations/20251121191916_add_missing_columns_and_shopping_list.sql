/*
  # Update Recipe Manager Schema

  1. Changes to Existing Tables
    - Add `category` column to recipes
    - Add `image_url` column to recipes
    - Add `date` column to meal_plans (to replace day text)
    - Add `servings` column to meal_plans
    - Rename `meal` to `meal_type` in meal_plans

  2. New Tables
    - `shopping_list_items`
      - `id` (uuid, primary key)
      - `ingredient_name` (text)
      - `quantity` (text)
      - `unit` (text)
      - `checked` (boolean)
      - `created_at` (timestamptz)

  3. Security
    - Enable RLS on shopping_list_items
    - Add public access policies for demo
*/

-- Add missing columns to recipes
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'recipes' AND column_name = 'category'
  ) THEN
    ALTER TABLE recipes ADD COLUMN category text DEFAULT 'dinner';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'recipes' AND column_name = 'image_url'
  ) THEN
    ALTER TABLE recipes ADD COLUMN image_url text DEFAULT '';
  END IF;
END $$;

-- Update meal_plans table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'meal_plans' AND column_name = 'date'
  ) THEN
    ALTER TABLE meal_plans ADD COLUMN date date DEFAULT CURRENT_DATE;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'meal_plans' AND column_name = 'servings'
  ) THEN
    ALTER TABLE meal_plans ADD COLUMN servings integer DEFAULT 4;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'meal_plans' AND column_name = 'meal_type'
  ) THEN
    IF EXISTS (
      SELECT 1 FROM information_schema.columns
      WHERE table_name = 'meal_plans' AND column_name = 'meal'
    ) THEN
      ALTER TABLE meal_plans RENAME COLUMN meal TO meal_type;
    ELSE
      ALTER TABLE meal_plans ADD COLUMN meal_type text NOT NULL DEFAULT 'dinner';
    END IF;
  END IF;
END $$;

-- Create shopping_list_items table
CREATE TABLE IF NOT EXISTS shopping_list_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ingredient_name text NOT NULL,
  quantity text DEFAULT '',
  unit text DEFAULT '',
  checked boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE shopping_list_items ENABLE ROW LEVEL SECURITY;

-- Create policies for shopping list (public access for demo)
CREATE POLICY "Anyone can view shopping list"
  ON shopping_list_items FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Anyone can insert shopping list items"
  ON shopping_list_items FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Anyone can update shopping list items"
  ON shopping_list_items FOR UPDATE
  TO anon
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anyone can delete shopping list items"
  ON shopping_list_items FOR DELETE
  TO anon
  USING (true);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_recipes_category ON recipes(category);
CREATE INDEX IF NOT EXISTS idx_meal_plans_date ON meal_plans(date);
CREATE INDEX IF NOT EXISTS idx_shopping_list_checked ON shopping_list_items(checked);