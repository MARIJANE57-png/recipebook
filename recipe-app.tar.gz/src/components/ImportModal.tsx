import { useState, useRef } from 'react';
import { X, Link, Video, Loader, Camera, Upload } from 'lucide-react';
import { Recipe } from '../types';

interface ImportModalProps {
  onImport: (recipe: Partial<Recipe>) => void;
  onCancel: () => void;
}

export default function ImportModal({ onImport, onCancel }: ImportModalProps) {
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [importType, setImportType] = useState<'url' | 'tiktok' | 'image'>('url');
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const compressImage = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;

          const maxDimension = 1600;
          if (width > maxDimension || height > maxDimension) {
            if (width > height) {
              height = (height / width) * maxDimension;
              width = maxDimension;
            } else {
              width = (width / height) * maxDimension;
              height = maxDimension;
            }
          }

          canvas.width = width;
          canvas.height = height;

          const ctx = canvas.getContext('2d');
          if (!ctx) {
            reject(new Error('Failed to get canvas context'));
            return;
          }

          ctx.drawImage(img, 0, 0, width, height);

          const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.85);
          resolve(compressedDataUrl);
        };
        img.onerror = () => reject(new Error('Failed to load image'));
        img.src = e.target?.result as string;
      };
      reader.onerror = () => reject(new Error('Failed to read file'));
      reader.readAsDataURL(file);
    });
  };

  const handleImageSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedImage(file);
      try {
        const compressedImage = await compressImage(file);
        setImagePreview(compressedImage);
        setError('');
      } catch (err) {
        setError('Failed to process image');
      }
    }
  };

  const handleImport = async () => {
    if (importType === 'image') {
      if (!imagePreview) {
        setError('Please select an image');
        return;
      }

      setLoading(true);
      setError('');

      try {
        const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/extract-recipe`;
        const response = await fetch(apiUrl, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            type: 'image',
            image: imagePreview
          }),
        });

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.error || 'Failed to extract recipe from image');
        }

        const recipe = await response.json();
        onImport(recipe);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to scan recipe');
      } finally {
        setLoading(false);
      }
    } else {
      if (!url.trim()) {
        setError('Please enter a URL');
        return;
      }

      setLoading(true);
      setError('');

      try {
        const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/extract-recipe`;
        const response = await fetch(apiUrl, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ url, type: importType }),
        });

        if (!response.ok) {
          throw new Error('Failed to extract recipe');
        }

        const recipe = await response.json();
        onImport(recipe);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to import recipe');
      } finally {
        setLoading(false);
      }
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b px-6 py-4 flex items-center justify-between rounded-t-lg">
          <h2 className="text-2xl font-bold text-gray-900">Import Recipe</h2>
          <button
            onClick={onCancel}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          <div className="grid grid-cols-3 gap-3">
            <button
              onClick={() => {
                setImportType('url');
                setSelectedImage(null);
                setImagePreview(null);
              }}
              className={`flex flex-col items-center justify-center gap-2 px-4 py-3 rounded-lg border-2 transition-colors ${
                importType === 'url'
                  ? 'border-emerald-600 bg-emerald-50 text-emerald-700'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <Link className="w-5 h-5" />
              <span className="font-medium text-xs">Website</span>
            </button>
            <button
              onClick={() => {
                setImportType('tiktok');
                setSelectedImage(null);
                setImagePreview(null);
              }}
              className={`flex flex-col items-center justify-center gap-2 px-4 py-3 rounded-lg border-2 transition-colors ${
                importType === 'tiktok'
                  ? 'border-emerald-600 bg-emerald-50 text-emerald-700'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <Video className="w-5 h-5" />
              <span className="font-medium text-xs">TikTok</span>
            </button>
            <button
              onClick={() => {
                setImportType('image');
                setUrl('');
              }}
              className={`flex flex-col items-center justify-center gap-2 px-4 py-3 rounded-lg border-2 transition-colors ${
                importType === 'image'
                  ? 'border-emerald-600 bg-emerald-50 text-emerald-700'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <Camera className="w-5 h-5" />
              <span className="font-medium text-xs">Scan</span>
            </button>
          </div>

          {importType === 'image' ? (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Upload Recipe Image
              </label>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                onChange={handleImageSelect}
                className="hidden"
              />

              {imagePreview ? (
                <div className="space-y-3">
                  <div className="relative rounded-lg overflow-hidden border-2 border-gray-200">
                    <img
                      src={imagePreview}
                      alt="Recipe preview"
                      className="w-full h-48 object-cover"
                    />
                    <button
                      onClick={() => {
                        setSelectedImage(null);
                        setImagePreview(null);
                        if (fileInputRef.current) {
                          fileInputRef.current.value = '';
                        }
                      }}
                      className="absolute top-2 right-2 p-1 bg-red-500 text-white rounded-full hover:bg-red-600"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg hover:bg-gray-50 transition-colors flex items-center justify-center gap-2"
                  >
                    <Upload className="w-4 h-4" />
                    Choose Different Image
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full px-4 py-8 border-2 border-dashed border-gray-300 rounded-lg hover:border-emerald-500 hover:bg-emerald-50 transition-colors flex flex-col items-center justify-center gap-3"
                >
                  <Camera className="w-12 h-12 text-gray-400" />
                  <div className="text-center">
                    <p className="font-medium text-gray-700">Take Photo or Upload Image</p>
                    <p className="text-sm text-gray-500 mt-1">Click to open camera or select from gallery</p>
                  </div>
                </button>
              )}

              {error && (
                <p className="mt-2 text-sm text-red-600">{error}</p>
              )}
            </div>
          ) : (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {importType === 'tiktok' ? 'TikTok Video URL' : 'Recipe Website URL'}
              </label>
              <input
                type="url"
                value={url}
                onChange={(e) => {
                  setUrl(e.target.value);
                  setError('');
                }}
                placeholder={
                  importType === 'tiktok'
                    ? 'https://www.tiktok.com/@username/video/...'
                    : 'https://www.example.com/recipe...'
                }
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                disabled={loading}
              />
              {error && (
                <p className="mt-2 text-sm text-red-600">{error}</p>
              )}
            </div>
          )}

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-sm text-blue-800">
              {importType === 'image' ? (
                <>
                  <strong>Scan Recipe:</strong> Take a photo of a recipe from a cookbook or magazine.
                  We'll use OCR to extract the recipe text automatically.
                </>
              ) : importType === 'tiktok' ? (
                <>
                  <strong>TikTok Import:</strong> Paste a TikTok recipe video URL. We'll extract
                  the recipe details from the video description and captions.
                </>
              ) : (
                <>
                  <strong>Website Import:</strong> Paste a URL from popular recipe sites like
                  AllRecipes, Food Network, BBC Good Food, and more.
                </>
              )}
            </p>
          </div>

          <div className="flex gap-3 pt-4 border-t">
            <button
              onClick={onCancel}
              className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              disabled={loading}
            >
              Cancel
            </button>
            <button
              onClick={handleImport}
              disabled={loading || (importType === 'image' && !imagePreview) || (importType !== 'image' && !url.trim())}
              className="flex-1 px-6 py-3 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <Loader className="w-5 h-5 animate-spin" />
                  {importType === 'image' ? 'Scanning...' : 'Importing...'}
                </>
              ) : (
                importType === 'image' ? 'Scan Recipe' : 'Import Recipe'
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
